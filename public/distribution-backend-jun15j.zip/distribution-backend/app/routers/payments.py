import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pymongo import ReturnDocument

from ..auth import get_current_user, is_staff, require_roles
from ..deps import current_company
from ..db import db
from ..ledger import compute, bill_breakdown
from ..models import ApproveIn, ChequeUpdate, CollectIn, DepositIn, ReconcileIn
from ..serializers import public_payment

router = APIRouter(prefix="/payments", tags=["payments"])
staff_only = require_roles("admin", "manager")


async def _next_receipt() -> int:
    doc = await db.counters.find_one_and_update(
        {"_id": "receipt"}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER)
    return 1000 + doc["seq"]


async def _summary(dealer_id):
    bills = [b async for b in db.bills.find({"dealer_id": dealer_id})]
    pays = [p async for p in db.payments.find({"dealer_id": dealer_id})]
    return compute(bills, pays)


@router.post("")
async def record_collection(body: CollectIn, company=Depends(current_company), user=Depends(get_current_user)):
    dealer = await db.dealers.find_one({"_id": body.dealer_id, "company_id": company})
    if not dealer:
        raise HTTPException(404, "Dealer not found")
    if not is_staff(user) and dealer.get("collector_id") != user["_id"]:
        raise HTTPException(403, "Not your dealer")
    if user["role"] == "manager" and not user.get("can_collect", False):
        raise HTTPException(403, "You are not allowed to record collections")
    if user["role"] == "collector" and user.get("block_collect", False):
        raise HTTPException(403, "Recording collections is disabled for your account")
    due = (await _summary(body.dealer_id))["outstanding"]
    if body.amount > due + 1:
        raise HTTPException(400, f"Amount exceeds outstanding of {due:.0f}")
    if body.mode.value == "Cheque" and not (body.cheque or "").strip():
        raise HTTPException(400, "Cheque number/bank is required for cheque payments")
    cheque_date = None
    if body.mode.value == "Cheque" and body.cheque_date:
        try:
            cheque_date = date.fromisoformat(body.cheque_date[:10]).isoformat()
        except ValueError:
            raise HTTPException(400, "Cheque date must be YYYY-MM-DD")
    receipt = await _next_receipt()
    pending = body.mode.value == "Cheque"
    approved = user["role"] != "collector"   # collector payments need approval
    payment = {"_id": uuid.uuid4().hex, "dealer_id": dealer["_id"], "dealer_name": dealer["name"],
               "collector_id": user["_id"], "collector_name": user["name"], "amount": body.amount,
               "mode": body.mode.value, "cheque": (body.cheque or "").strip(), "cheque_date": cheque_date, "date": date.today().isoformat(),
               "ts": datetime.now(timezone.utc), "receipt": receipt,
               "status": "pending" if pending else "cleared", "deposited": False, "approved": approved,
               "approved_by": (user["name"] if approved else None), "reconciled": False, "company_id": company}
    await db.payments.insert_one(payment)
    out = public_payment(payment)
    out["new_outstanding"] = (await _summary(dealer["_id"]))["outstanding"]
    return out


@router.get("")
async def list_payments(dealer_id: Optional[str] = None, status: Optional[str] = None,
                        day: Optional[str] = None, company=Depends(current_company), user=Depends(get_current_user)):
    query = {"company_id": company}
    if not is_staff(user):
        query["collector_id"] = user["_id"]
    if dealer_id:
        query["dealer_id"] = dealer_id
    if status:
        query["status"] = status
    if day:
        query["date"] = day
    return [public_payment(p) async for p in db.payments.find(query).sort("ts", -1)]


@router.patch("/{pid}/cheque")
async def update_cheque(pid: str, body: ChequeUpdate, _=Depends(require_roles("admin"))):
    p = await db.payments.find_one({"_id": pid})
    if not p:
        raise HTTPException(404, "Payment not found")
    if p["mode"] != "Cheque" or p["status"] != "pending":
        raise HTTPException(400, "Only pending cheques can be updated")
    if body.cleared and p.get("cheque_date") and p["cheque_date"] > date.today().isoformat():
        raise HTTPException(400, f"Post-dated cheque — can be cleared only on or after {p['cheque_date']}")
    await db.payments.update_one({"_id": pid}, {"$set": {"status": "cleared" if body.cleared else "bounced"}})
    return {"ok": True}


@router.post("/deposit")
async def deposit_cash(body: DepositIn, _=Depends(require_roles("admin"))):
    r = await db.payments.update_many(
        {"collector_id": body.collector_id, "mode": "Cash", "deposited": False, "status": "cleared"},
        {"$set": {"deposited": True}})
    return {"ok": True, "marked": r.modified_count}


@router.get("/pending")
async def pending_approvals(company=Depends(current_company), _=Depends(staff_only)):
    return [public_payment(p) async for p in db.payments.find({"approved": False, "company_id": company}).sort("ts", -1)]


@router.patch("/{pid}/approve")
async def approve_payment(pid: str, body: ApproveIn, _=Depends(staff_only)):
    p = await db.payments.find_one({"_id": pid})
    if not p:
        raise HTTPException(404, "Payment not found")
    if p.get("approved", True):
        raise HTTPException(400, "Already approved")
    if body.approved:
        await db.payments.update_one({"_id": pid}, {"$set": {"approved": True, "approved_by": _["name"]}})
    else:
        await db.payments.delete_one({"_id": pid})
    return {"ok": True}


@router.delete("/{pid}")
async def delete_payment(pid: str, _=Depends(require_roles("admin"))):
    r = await db.payments.delete_one({"_id": pid})
    if r.deleted_count == 0:
        raise HTTPException(404, "Payment not found")
    return {"ok": True}


@router.get("/collections")
async def collections(reconciled: Optional[bool] = None, company=Depends(current_company), _=Depends(require_roles("admin"))):
    q = {"approved": {"$ne": False}, "collector_id": {"$nin": [None, "seed"]}, "company_id": company}
    if reconciled is True:
        q["reconciled"] = True
    elif reconciled is False:
        q["reconciled"] = {"$ne": True}
    return [public_payment(p) async for p in db.payments.find(q).sort("ts", -1)]


@router.patch("/{pid}/reconcile")
async def reconcile_payment(pid: str, body: ReconcileIn, _=Depends(require_roles("admin"))):
    r = await db.payments.update_one({"_id": pid}, {"$set": {"reconciled": body.reconciled}})
    if r.matched_count == 0:
        raise HTTPException(404, "Payment not found")
    return {"ok": True}


@router.get("/summary")
async def dashboard(company=Depends(current_company), _=Depends(staff_only)):
    dealers = [d async for d in db.dealers.find({"company_id": company, "show_on_overview": {"$ne": False}})]
    hidden_count = await db.dealers.count_documents({"company_id": company, "show_on_overview": False})
    bills_by, pays_by = {}, {}
    async for b in db.bills.find({"company_id": company}):
        bills_by.setdefault(b["dealer_id"], []).append(b)
    all_pays = [p async for p in db.payments.find({"company_id": company})]
    for p in all_pays:
        pays_by.setdefault(p["dealer_id"], []).append(p)
    today_d = date.today()
    today = today_d.isoformat()
    total_out = over90 = 0
    ageing_total = {"age_0_30": 0, "age_31_60": 0, "age_61_90": 0, "age_90p": 0}
    overdue_rows = []
    for d in dealers:
        bl = bills_by.get(d["_id"], []); pz = pays_by.get(d["_id"], [])
        s = compute(bl, pz)
        total_out += s["outstanding"]
        over90 += s["ageing"].get("age_90p", 0)
        for k in ageing_total:
            ageing_total[k] += s["ageing"].get(k, 0)
        if s["outstanding"] > 0:
            oldest = max((b["days"] for b in bill_breakdown(bl, pz)), default=0)
            overdue_rows.append({"name": d["name"], "area": d.get("area"), "outstanding": s["outstanding"],
                                 "age_90p": s["ageing"].get("age_90p", 0), "oldest_due": oldest})
    field_pays = [p for p in all_pays if p.get("collector_id") not in (None, "seed") and p.get("approved", True)]
    pending_count = sum(1 for p in all_pays if p.get("approved") is False)
    collected_today = sum(p["amount"] for p in field_pays if p["date"] == today and p["status"] != "bounced")
    cash_undeposited = sum(p["amount"] for p in field_pays
                           if p["mode"] == "Cash" and not p.get("deposited") and p["status"] == "cleared")
    cheques_pending = sum(p["amount"] for p in field_pays if p["status"] == "pending")
    users = [u async for u in db.users.find({"role": "collector"})]
    users = [u for u in users if company in (u.get("company_ids") or [])] or users
    per_collector = []
    for u in users:
        got = sum(p["amount"] for p in field_pays
                  if p["collector_id"] == u["_id"] and p["date"] == today and p["status"] != "bounced")
        assigned = sum(1 for d in dealers if d.get("collector_id") == u["_id"])
        per_collector.append({"id": u["_id"], "name": u["name"], "dealers": assigned, "collected_today": got})
    week_start = (today_d - timedelta(days=6)).isoformat()
    month_start = today_d.replace(day=1).isoformat()
    collected_week = sum(p["amount"] for p in field_pays if p["date"] >= week_start and p["status"] != "bounced")
    collected_month = sum(p["amount"] for p in field_pays if p["date"] >= month_start and p["status"] != "bounced")
    daily = []
    for i in range(13, -1, -1):
        dd = (today_d - timedelta(days=i)).isoformat()
        daily.append({"date": dd, "amount": sum(p["amount"] for p in field_pays if p["date"] == dd and p["status"] != "bounced")})
    top_overdue = sorted(overdue_rows, key=lambda r: (-r["oldest_due"], -r["outstanding"]))[:8]
    return {"hidden_dealers": hidden_count, "total_outstanding": total_out, "over_90_days": over90, "collected_today": collected_today,
            "collected_week": collected_week, "collected_month": collected_month, "daily": daily,
            "top_overdue": top_overdue, "ageing": ageing_total, "cash_undeposited": cash_undeposited, "cheques_pending": cheques_pending,
            "pending_approvals": pending_count, "per_collector": per_collector}
