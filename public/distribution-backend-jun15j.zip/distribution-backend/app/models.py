from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Role(str, Enum):
    admin = "admin"
    manager = "manager"
    collector = "collector"


class Mode(str, Enum):
    cash = "Cash"
    cheque = "Cheque"
    upi = "UPI"
    rtgs = "RTGS"


class Ageing(BaseModel):
    """Outstanding split into ageing buckets (in rupees)."""
    age_0_30: float = 0
    age_31_60: float = 0
    age_61_90: float = 0
    age_90p: float = 0


# ---- auth ----
class BootstrapIn(BaseModel):
    name: str
    pin: str = Field(min_length=4, max_length=8)


class LoginIn(BaseModel):
    name: str
    pin: str


# ---- users ----
class UserIn(BaseModel):
    name: str
    pin: str = Field(min_length=4, max_length=8)
    role: Role = Role.collector
    price_list_access: bool = False
    can_collect: bool = False
    block_collect: bool = False
    can_import_statement: bool = False
    can_view_reports: bool = False
    can_view_dashboard: bool = False
    can_view_sales: bool = False
    can_view_profit: bool = False
    can_view_digest: bool = False
    can_view_stock_prices: bool = False
    can_view_payments: bool = False
    company_ids: list[str] = []


class UserPatch(BaseModel):
    name: Optional[str] = None
    pin: Optional[str] = Field(default=None, min_length=4, max_length=8)
    role: Optional[Role] = None
    price_list_access: Optional[bool] = None
    can_collect: Optional[bool] = None
    block_collect: Optional[bool] = None
    can_import_statement: Optional[bool] = None
    can_view_reports: Optional[bool] = None
    can_view_dashboard: Optional[bool] = None
    can_view_sales: Optional[bool] = None
    can_view_profit: Optional[bool] = None
    can_view_digest: Optional[bool] = None
    can_view_stock_prices: Optional[bool] = None
    can_view_payments: Optional[bool] = None
    company_ids: Optional[list[str]] = None


# ---- dealers ----
class DealerIn(BaseModel):
    name: str
    area: Optional[str] = None
    phone: Optional[str] = None
    credit_limit: float = 0
    collector_id: Optional[str] = None
    show_on_overview: bool = True
    ageing: Ageing = Field(default_factory=Ageing)


class DealerPatch(BaseModel):
    name: Optional[str] = None
    area: Optional[str] = None
    phone: Optional[str] = None
    credit_limit: Optional[float] = None
    collector_id: Optional[str] = None
    show_on_overview: Optional[bool] = None
    ageing: Optional[Ageing] = None


# ---- stock ----
class StockIn(BaseModel):
    name: str
    price: float = 0
    qty: int = 0


class StockPatch(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    qty: Optional[int] = None


# ---- payments ----
class CollectIn(BaseModel):
    dealer_id: str
    amount: float = Field(gt=0)
    mode: Mode = Mode.cash
    cheque: Optional[str] = None
    cheque_date: Optional[str] = None   # post-dated cheque (YYYY-MM-DD)


class ChequeUpdate(BaseModel):
    cleared: bool  # True -> cleared, False -> bounced (restores outstanding)


class DepositIn(BaseModel):
    collector_id: str


class ApproveIn(BaseModel):
    approved: bool


class ReconcileIn(BaseModel):
    reconciled: bool


class VisitIn(BaseModel):
    lat: Optional[float] = None
    lng: Optional[float] = None


# ---- products / price list ----
class ProductIn(BaseModel):
    category: str
    model: str
    description: Optional[str] = ""
    mrp: Optional[float] = None
    dp: Optional[float] = None
    nlc: Optional[float] = None


class ProductBulk(BaseModel):
    products: list[ProductIn]


class ProductPatch(BaseModel):
    category: Optional[str] = None
    model: Optional[str] = None
    description: Optional[str] = None
    mrp: Optional[float] = None
    dp: Optional[float] = None
    nlc: Optional[float] = None


class FlexImport(BaseModel):
    columns: list[str]
    model_col: Optional[str] = None
    price_col: Optional[str] = None
    rows: list[dict]


class CellRow(BaseModel):
    cells: dict


# ---- price lists (faithful, multi-sheet, any columns) ----
class PriceSheet(BaseModel):
    name: str
    columns: list[str]
    rows: list[list]


# ---- price lists (multi-brand) ----
class PriceListIn(BaseModel):
    name: str
    allowed_user_ids: list[str] = []


class PriceListPatch(BaseModel):
    name: Optional[str] = None
    allowed_user_ids: Optional[list[str]] = None
    columns: Optional[list[str]] = None
    model_col: Optional[str] = None
    price_col: Optional[str] = None


# ---- bills / ledger ----
class BillIn(BaseModel):
    bill_no: str
    date: str          # YYYY-MM-DD
    amount: float = Field(gt=0)
    source: Optional[str] = None   # 'manual' (default) or 'pdf'


class SeedPayment(BaseModel):
    ref: Optional[str] = ""
    date: Optional[str] = None
    amount: float


class SeedIn(BaseModel):
    opening: float = 0
    opening_date: Optional[str] = None
    bills: list[BillIn] = []
    payments: list[SeedPayment] = []


class BulkBillRow(BaseModel):
    dealer_id: Optional[str] = None
    dealer_name: Optional[str] = None
    bill_no: str
    date: str
    amount: float


class BulkBills(BaseModel):
    bills: list[BulkBillRow]


class MergeIn(BaseModel):
    source_ids: list[str] = []


# ---- companies (multi-company) ----
class CompanyIn(BaseModel):
    name: str
    kind: str = "distribution"


class CompanyPatch(BaseModel):
    name: Optional[str] = None


# ---- orders ----
class OrderItem(BaseModel):
    model: str
    description: Optional[str] = ""
    brand: Optional[str] = ""
    dp: float = 0
    qty: float = Field(gt=0)
    billed_units: Optional[float] = 0   # units of this model already billed to the dealer
    billed_value: Optional[float] = 0   # ₹ value of those already-billed units


class OrderIn(BaseModel):
    dealer_id: str
    pricelist_name: Optional[str] = ""
    note: Optional[str] = ""
    items: list[OrderItem]


class ExecuteIn(BaseModel):
    bill_no: Optional[str] = ""
