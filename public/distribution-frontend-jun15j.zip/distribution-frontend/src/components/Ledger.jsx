import { inr } from '../lib/format.js'
import { Trash2, Eye } from 'lucide-react'

const BUCKETS = { age_0_30: '0–30', age_31_60: '31–60', age_61_90: '61–90', age_90p: '90+' }
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
function monthLabel(d) {
  if (!d) return ''
  const [y, m] = d.split('-')
  return `${MONTHS[(+m || 1) - 1]} ${y}`
}
function fmtDay(d) {
  if (!d) return ''
  const [, m, day] = d.split('-')
  return `${day} ${MONTHS[(+m || 1) - 1]}`
}

const AGE = [['age_0_30', '0–30', '#12a184'], ['age_31_60', '31–60', '#5B8A72'],
  ['age_61_90', '61–90', '#B4884A'], ['age_90p', '90+', '#B23A32']]

// Header card: outstanding, credit-limit usage, ageing bar, last payment.
export function LedgerHeader({ name, outstanding, ageing = {}, creditLimit = 0, lastPayment }) {
  const total = AGE.reduce((s, [k]) => s + (ageing[k] || 0), 0) || 1
  const over = creditLimit > 0 && outstanding > creditLimit
  const pct = creditLimit > 0 ? Math.min(100, (outstanding / creditLimit) * 100) : 0
  return (
    <div className="bg-white dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800 rounded-2xl p-4 mb-3 shadow-soft">
      {name && <div className="font-display text-lg font-bold leading-tight text-slate-900 dark:text-slate-100">{name}</div>}
      <div className="flex items-baseline gap-2 mt-1">
        <div className="font-display text-[26px] font-bold tracking-tight text-slate-900 dark:text-slate-100">{inr(outstanding)}</div>
        <div className="text-[11px] text-slate-500 dark:text-slate-400">outstanding</div>
      </div>

      {creditLimit > 0 && (
        <>
          <div className="h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden mt-2">
            <div className={'h-full transition-all ' + (over ? 'bg-red-600' : 'bg-brand-600')} style={{ width: pct + '%' }} />
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            of {inr(creditLimit)} limit{over && <span className="text-red-700 dark:text-red-400 font-semibold"> · over limit</span>}
          </div>
        </>
      )}

      {outstanding > 0 && (
        <div className="mt-3">
          <div className="flex h-2 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800">
            {AGE.map(([k, , c]) => (ageing[k] > 0 ? <div key={k} style={{ width: (ageing[k] / total) * 100 + '%', background: c }} /> : null))}
          </div>
          <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5">
            {AGE.map(([k, label, c]) => (ageing[k] > 0 ? (
              <span key={k} className="text-[10.5px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-sm inline-block" style={{ background: c }} />{label}: <b className="text-slate-700 dark:text-slate-200">{inr(ageing[k])}</b>
              </span>
            ) : null))}
          </div>
        </div>
      )}

      {lastPayment && (
        <div className="text-[12px] text-slate-500 dark:text-slate-400 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          Last payment <b className="text-brand-700 dark:text-brand-400">{inr(lastPayment.amount)}</b> · {fmtDay(lastPayment.date)} {lastPayment.date?.slice(0, 4)}
        </div>
      )}
    </div>
  )
}

// Traditional khata: oldest at top, balance builds down, grouped by month.
export function LedgerTable({ entries = [], onDelete, onBill }) {
  if (!entries.length) {
    return <div className="bg-white dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800 rounded-2xl p-4 text-[12px] text-slate-400 dark:text-slate-500 shadow-soft">No entries yet.</div>
  }
  let lastMonth = null
  return (
    <div className="bg-white dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800 rounded-2xl overflow-hidden shadow-soft">
      <div className="flex items-center px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-[10.5px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
        <div className="flex-1">Particulars</div>
        <div className="w-20 text-right">Debit</div>
        <div className="w-20 text-right">Credit</div>
        <div className="w-24 text-right">Balance</div>
      </div>
      {entries.map((e, i) => {
        const m = monthLabel(e.date)
        const showMonth = m !== lastMonth
        lastMonth = m
        const isBill = e.type === 'bill'
        return (
          <div key={i}>
            {showMonth && <div className="px-3 py-1 bg-slate-50/70 dark:bg-slate-800/40 text-[10.5px] font-semibold text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800">{m}</div>}
            <div className="flex items-center px-3 py-2.5 border-b border-slate-50 dark:border-slate-800/70 last:border-0 text-[13px] hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
              {isBill && onBill && e.id ? (
                <button data-testid={'ledger-bill-' + (e.ref || i)} onClick={() => onBill(e)} className="flex-1 min-w-0 pr-2 text-left group/bill">
                  <div className="font-semibold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1 group-hover/bill:text-brand-700 dark:group-hover/bill:text-brand-400">
                    {e.ref === 'Opening' ? 'Opening balance' : 'Bill ' + e.ref}<Eye size={12} className="opacity-40 shrink-0" />
                  </div>
                  <div className="text-[11px] text-slate-400 dark:text-slate-500">
                    {fmtDay(e.date)}
                    {e.debit > 0 && e.days != null && e.ref !== 'Opening' && (
                      <span className={e.bucket === 'age_90p' ? 'text-red-600 dark:text-red-400 font-semibold' : ''}> · {e.days}d ({BUCKETS[e.bucket]})</span>
                    )}
                  </div>
                </button>
              ) : (
              <div className="flex-1 min-w-0 pr-2">
                <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                  {isBill ? (e.ref === 'Opening' ? 'Opening balance' : 'Bill ' + e.ref) : (e.mode || 'Payment') + (e.ref && e.ref !== e.mode ? ' ' + e.ref : '')}
                </div>
                <div className="text-[11px] text-slate-400 dark:text-slate-500">
                  {fmtDay(e.date)}
                  {isBill && e.debit > 0 && e.days != null && e.ref !== 'Opening' && (
                    <span className={e.bucket === 'age_90p' ? 'text-red-600 dark:text-red-400 font-semibold' : ''}> · {e.days}d ({BUCKETS[e.bucket]})</span>
                  )}
                </div>
              </div>
              )}
              <div className="w-20 text-right font-semibold text-slate-800 dark:text-slate-200">{e.debit ? inr(e.debit) : ''}</div>
              <div className="w-20 text-right font-semibold text-brand-700 dark:text-brand-400">{e.credit ? inr(e.credit) : ''}</div>
              <div className="w-24 text-right font-bold text-slate-900 dark:text-slate-100">{inr(e.balance)}</div>
              {onDelete && <div className="w-7 text-right">{e.id ? <button data-testid={'ledger-del-' + (e.ref || e.id)} onClick={() => onDelete(e)} className="text-red-400 hover:text-red-600 p-1 transition-colors"><Trash2 size={13} /></button> : null}</div>}
            </div>
          </div>
        )
      })}
      <div className="flex items-center px-3 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-t-2 border-slate-200 dark:border-slate-700 text-[13px] font-bold">
        <div className="flex-1 text-slate-700 dark:text-slate-200">Total</div>
        <div className="w-20 text-right text-slate-900 dark:text-slate-100">{inr(entries.reduce((s, e) => s + (e.debit || 0), 0))}</div>
        <div className="w-20 text-right text-brand-700 dark:text-brand-400">{inr(entries.reduce((s, e) => s + (e.credit || 0), 0))}</div>
        <div className="w-24 text-right text-slate-900 dark:text-slate-100">{inr(entries[entries.length - 1]?.balance || 0)}</div>
        {onDelete && <div className="w-7" />}
      </div>
    </div>
  )
}
