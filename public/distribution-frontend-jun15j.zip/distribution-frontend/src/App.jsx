import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './auth/AuthContext.jsx'
import Shell from './components/Shell.jsx'
import Login from './pages/Login.jsx'
import CompanyPicker from './pages/CompanyPicker.jsx'

import Beat from './pages/collector/Beat.jsx'
import Dealer from './pages/collector/Dealer.jsx'
import Collect from './pages/collector/Collect.jsx'
import MyDay from './pages/collector/MyDay.jsx'
import StockView from './pages/collector/StockView.jsx'

import Dashboard from './pages/staff/Dashboard.jsx'
import AdminDashboard from './pages/staff/AdminDashboard.jsx'
import Dealers from './pages/staff/Dealers.jsx'
import Stock from './pages/staff/Stock.jsx'
import Money from './pages/staff/Money.jsx'
import Users from './pages/staff/Users.jsx'
import Approvals from './pages/staff/Approvals.jsx'
import Reconcile from './pages/staff/Reconcile.jsx'
import Reports from './pages/staff/Reports.jsx'
import Orders from './pages/staff/Orders.jsx'
import Imports from './pages/staff/Imports.jsx'
import CompanyPayments from './pages/staff/CompanyPayments.jsx'
import Prices from './pages/Prices.jsx'
import DailyCollections from './pages/dc/DailyCollections.jsx'
import DcHub from './pages/dc/DcHub.jsx'

export default function App() {
  const { auth, company } = useAuth()

  if (!auth) {
    return (
      <Routes>
        <Route path="*" element={<Login />} />
      </Routes>
    )
  }

  if (!company) return <CompanyPicker />

  const role = auth.user.role
  const canReports = role === 'admin' || auth.user.can_view_reports
  const canDash = role === 'admin' || auth.user.can_view_dashboard
  const canPay = role === 'admin' || auth.user.can_view_payments

  return (
    <Routes>
      <Route element={<Shell />}>
        {company.kind === 'daily_collections' ? (
          <Route path="*" element={<DcHub />} />
        ) : role === 'collector' ? (
          <>
            <Route path="/" element={<Beat />} />
            <Route path="/dealer/:id" element={<Dealer />} />
            <Route path="/collect/:id" element={<Collect />} />
            <Route path="/stock" element={<StockView />} />
            <Route path="/myday" element={<MyDay />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/prices" element={<Prices />} />
            {canReports && <Route path="/reports" element={<Reports />} />}
          </>
        ) : (
          <>
            <Route path="/" element={<Dashboard />} />
            {canDash && <Route path="/dashboard" element={<AdminDashboard />} />}
            <Route path="/dealers" element={<Dealers />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/stock" element={<Stock />} />
            <Route path="/imports" element={<Imports />} />
            {canPay && <Route path="/payments" element={<CompanyPayments />} />}
            {role === 'admin' && <Route path="/money" element={<Money />} />}
            {role === 'admin' && <Route path="/reconcile" element={<Reconcile />} />}
            {canReports && <Route path="/reports" element={<Reports />} />}
            <Route path="/prices" element={<Prices />} />
            <Route path="/approvals" element={<Approvals />} />
            {role === 'admin' && <Route path="/users" element={<Users />} />}
          </>
        )}
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
