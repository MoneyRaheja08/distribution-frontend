import * as mock from './mock.js'

const BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'
const USE_MOCK = String(import.meta.env.VITE_USE_MOCK) === 'true'

let token = null
export const setToken = (t) => { token = t }

let company = null
export const setCompany = (c) => { company = c }

let lastSync = null
export const getLastSync = () => lastSync
function markSync() { lastSync = Date.now(); try { window.dispatchEvent(new Event('api:sync')) } catch { /* noop */ } }

async function http(path, { method = 'GET', body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(company ? { 'X-Company-Id': company } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  })
  if (!res.ok) {
    let detail
    try { detail = (await res.json()).detail } catch { /* ignore */ }
    throw new Error(detail || `Request failed (${res.status})`)
  }
  const data = await res.json(); markSync(); return data
}

async function httpForm(path, formData) {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(company ? { 'X-Company-Id': company } : {}) },
    body: formData,
  })
  if (!res.ok) {
    let detail
    try { detail = (await res.json()).detail } catch { /* ignore */ }
    throw new Error(detail || `Request failed (${res.status})`)
  }
  const data = await res.json(); markSync(); return data
}

// Each method maps 1:1 to a FastAPI endpoint. Flip VITE_USE_MOCK to switch.
export const api = {
  login: (name, pin) => USE_MOCK ? mock.login(name, pin) : http('/auth/login', { method: 'POST', body: { name, pin } }),
  me: () => USE_MOCK ? mock.me() : http('/auth/me'),
  companies: () => USE_MOCK ? mock.companies() : http('/companies'),
  createCompany: (name, kind = 'distribution') => USE_MOCK ? mock.createCompany(name) : http('/companies', { method: 'POST', body: { name, kind } }),
  dcBills: (params = '') => USE_MOCK ? mock.empty({ rows: [], totals: {}, is_admin: false }) : http('/dc/bills' + params),
  dcCreateBill: (body) => USE_MOCK ? mock.empty({}) : http('/dc/bills', { method: 'POST', body }),
  dcUpdateBill: (id, body) => USE_MOCK ? mock.empty({}) : http('/dc/bills/' + id, { method: 'PATCH', body }),
  dcCollect: (id, body) => USE_MOCK ? mock.empty({}) : http('/dc/bills/' + id + '/collect', { method: 'POST', body }),
  dcDeleteBill: (id) => USE_MOCK ? mock.empty({ ok: true }) : http('/dc/bills/' + id, { method: 'DELETE' }),
  dcPending: (params = '') => USE_MOCK ? mock.empty({ rows: [], total: 0, count: 0 }) : http('/dc/pending' + params),
  dcExpenses: (params = '') => USE_MOCK ? mock.empty({ rows: [], total: 0 }) : http('/dc/expenses' + params),
  dcCreateExpense: (body) => USE_MOCK ? mock.empty({}) : http('/dc/expenses', { method: 'POST', body }),
  dcDeleteExpense: (id) => USE_MOCK ? mock.empty({ ok: true }) : http('/dc/expenses/' + id, { method: 'DELETE' }),
  dcDay: (date) => USE_MOCK ? mock.empty({}) : http('/dc/day' + (date ? '?date=' + date : '')),
  dcSaveRecon: (body) => USE_MOCK ? mock.empty({ ok: true }) : http('/dc/recon', { method: 'PUT', body }),
  dcReports: (frm, to) => USE_MOCK ? mock.empty({ totals: {}, by_pay: {}, by_day: [], by_staff: [], by_category: {} }) : http('/dc/reports?frm=' + frm + '&to=' + to),
  dcList: (name) => USE_MOCK ? mock.empty({ rows: [] }) : http('/dc/coll/' + name),
  dcAdd: (name, body) => USE_MOCK ? mock.empty({}) : http('/dc/coll/' + name, { method: 'POST', body }),
  dcPatch: (name, id, body) => USE_MOCK ? mock.empty({ ok: true }) : http('/dc/coll/' + name + '/' + id, { method: 'PATCH', body }),
  dcRemove: (name, id) => USE_MOCK ? mock.empty({ ok: true }) : http('/dc/coll/' + name + '/' + id, { method: 'DELETE' }),
  orders: (status) => USE_MOCK ? mock.orders(status) : http('/orders' + (status ? '?status=' + status : '')),
  orderDealerModels: (dealerId) => USE_MOCK ? mock.empty({ stock: [], billed: {} }) : http('/orders/dealer-models?dealer_id=' + encodeURIComponent(dealerId)),
  createOrder: (body) => USE_MOCK ? mock.createOrder(body) : http('/orders', { method: 'POST', body }),
  executeOrder: (id, bill_no) => USE_MOCK ? mock.executeOrder(id, bill_no) : http('/orders/' + id + '/execute', { method: 'PATCH', body: { bill_no } }),
  deleteOrder: (id) => USE_MOCK ? mock.deleteOrder(id) : http('/orders/' + id, { method: 'DELETE' }),
  renameCompany: (id, name) => USE_MOCK ? mock.renameCompany(id, name) : http('/companies/' + id, { method: 'PATCH', body: { name } }),

  summary: () => USE_MOCK ? mock.summary() : http('/payments/summary'),

  dealers: () => USE_MOCK ? mock.dealers() : http('/dealers'),
  dealer: (id) => USE_MOCK ? mock.dealer(id) : http('/dealers/' + id),
  saveDealer: (d) => USE_MOCK ? mock.save('dealers', d)
    : http(d.id ? '/dealers/' + d.id : ('/dealers?opening_balance=' + (d.opening_balance || 0)), { method: d.id ? 'PATCH' : 'POST', body: d }),
  dealerLedger: (id) => USE_MOCK ? mock.dealerLedger(id) : http('/dealers/' + id + '/ledger'),
  markVisited: (id, coords) => USE_MOCK ? mock.markVisited(id, coords) : http('/dealers/' + id + '/visit', { method: 'POST', body: coords || {} }),
  visitsToday: () => USE_MOCK ? mock.visitsToday() : http('/visits/today'),
  reportCollections: (from, to) => USE_MOCK ? mock.reportCollections() : http('/reports/collections?from=' + from + '&to=' + to),
  reportAgeing: () => USE_MOCK ? mock.reportAgeing() : http('/reports/ageing'),
  reportActivity: (from, to) => USE_MOCK ? mock.reportActivity() : http('/reports/activity?from=' + from + '&to=' + to),
  reportSalesVsColl: (from, to) => USE_MOCK ? mock.reportSalesVsColl() : http('/reports/sales-vs-collection?from=' + from + '&to=' + to),
  reportBillAgeing: () => USE_MOCK ? mock.reportBillAgeing() : http('/reports/bill-ageing'),
  reportBills: (from, to, source) => USE_MOCK ? mock.reportBills(from, to, source) : http('/reports/bills?from=' + from + '&to=' + to + (source ? '&source=' + source : '')),
  reportSales: (from, to, q = '', f = {}) => USE_MOCK ? mock.reportSales(from, to, q) : http('/reports/sales?from=' + from + '&to=' + to + (q ? '&q=' + encodeURIComponent(q) : '') + (f.brand ? '&brand=' + encodeURIComponent(f.brand) : '') + (f.dealer ? '&dealer=' + encodeURIComponent(f.dealer) : '') + (f.model ? '&model=' + encodeURIComponent(f.model) : '')),
  reportPurchasesBrand: (from, to, brand = '') => USE_MOCK ? mock.reportPurchasesBrand(from, to, brand) : http('/reports/purchases-brand?from=' + from + '&to=' + to + (brand ? '&brand=' + encodeURIComponent(brand) : '')),
  reportProfit: (from, to, brand = '') => USE_MOCK ? mock.reportProfit(from, to, brand) : http('/reports/profit?from=' + from + '&to=' + to + (brand ? '&brand=' + encodeURIComponent(brand) : '')),
  reportProfit2: (from, to, brand = '') => USE_MOCK ? mock.reportProfit2(from, to, brand) : http('/reports/profit2?from=' + from + '&to=' + to + (brand ? '&brand=' + encodeURIComponent(brand) : '')),
  reportProfitByDealer: (from, to, brand = '') => USE_MOCK ? mock.empty({ from, to, brand, brands: [], units: 0, total_sale: 0, total_cost: 0, total_margin: 0, total_margin_pct: 0, rows: [] }) : http('/reports/profit-by-dealer?from=' + from + '&to=' + to + (brand ? '&brand=' + encodeURIComponent(brand) : '')),
  reportBrandScorecard: (from, to) => USE_MOCK ? mock.reportBrandScorecard(from, to) : http('/reports/brand-scorecard?from=' + from + '&to=' + to),
  reportTopPerformers: (from, to, f = {}) => USE_MOCK ? mock.reportTopPerformers(from, to) : http('/reports/top-performers?from=' + from + '&to=' + to + '&' + new URLSearchParams(Object.entries(f).filter(([, v]) => v !== '' && v != null)).toString()),
  reportStockPlanner: (f = {}) => USE_MOCK ? mock.empty({ rows: [], fastest: [], lowest: [], to_order: [], counts: {}, brands: [], total_stock: 0, total_value: 0, order_units: 0, slow_value: 0, over_value: 0, lead_days: 7, cover_days: 30 }) : http('/reports/stock-planner?' + new URLSearchParams(Object.entries(f).filter(([, v]) => v !== '' && v != null)).toString()),
  reportPurchases: (from, to, f = {}) => USE_MOCK ? mock.empty({ rows: [], total: 0, units: 0, count: 0, bills: 0, suppliers: [], models: [], groups: [], brands: [], by_supplier: [], by_model: [], by_bill: [], by_group: [] }) : http('/reports/purchases?from=' + from + '&to=' + to + '&' + new URLSearchParams(Object.entries(f).filter(([, v]) => v !== '' && v != null)).toString()),
  reportDealerScorecard: (from, to) => USE_MOCK ? mock.empty({ rows: [], totals: {} }) : http('/reports/dealer-scorecard?from=' + from + '&to=' + to),
  reportCreditTrend: (months) => USE_MOCK ? mock.empty({ months: [], rows: [], warnings: 0 }) : http('/reports/credit-trend?months=' + months),
  reportInactive: (days) => USE_MOCK ? mock.empty({ rows: [], count: 0, regular_lost: 0, lost_revenue: 0 }) : http('/reports/inactive-dealers?days=' + days),
  reportMoM: (month, by) => USE_MOCK ? mock.empty({ month, periods: { cur: month, prev: month, ly: month }, rows: [], totals: { cur: { sale: 0, margin: 0, units: 0 }, prev: { sale: 0, margin: 0, units: 0 }, ly: { sale: 0, margin: 0, units: 0 } } }) : http('/reports/mom?month=' + month + '&by=' + by),
  reportCategoryMix: (from, to, brand = '') => USE_MOCK ? mock.empty({ rows: [], brands: [], total_sale: 0, total_margin: 0, margin_pct: 0 }) : http('/reports/category-mix?from=' + from + '&to=' + to + (brand ? '&brand=' + encodeURIComponent(brand) : '')),
  reportPrice: (from, to, brand = '') => USE_MOCK ? mock.empty({ rows: [], brands: [], below_cost: 0, total_leak: 0 }) : http('/reports/price-realisation?from=' + from + '&to=' + to + (brand ? '&brand=' + encodeURIComponent(brand) : '')),
  reportCashflow: () => USE_MOCK ? mock.empty({ as_of: '', weeks: [], next30: 0, beyond: 0, at_risk: 0, rows: [] }) : http('/reports/cashflow'),
  reportCollectorEff: (from, to, pct) => USE_MOCK ? mock.empty({ rows: [], totals: { collected: 0, outstanding: 0, visits: 0, commission: 0 } }) : http('/reports/collector-efficiency?from=' + from + '&to=' + to + '&commission_pct=' + pct),
  schemesList: (month) => USE_MOCK ? mock.empty({ month, rows: [], earned: 0, potential: 0, month_progress_pct: 0, groups: [], models: [], brands: [] }) : http('/reports/schemes?month=' + month),
  schemeCreate: (body) => USE_MOCK ? mock.empty({}) : http('/reports/schemes', { method: 'POST', body }),
  schemeStatus: (id, body) => USE_MOCK ? mock.empty({}) : http('/reports/schemes/' + id + '/status', { method: 'PATCH', body }),
  schemeDelete: (id) => USE_MOCK ? mock.empty({}) : http('/reports/schemes/' + id, { method: 'DELETE' }),
  reportDigest: (day) => USE_MOCK ? mock.empty({ day, sales: { amount: 0, units: 0, lines: 0, bills: 0, bill_amount: 0, by_dealer: [] }, collections: { amount: 0, receipts: 0, rows: [] }, outstanding: 0, over90: 0, top_overdue: [], low_stock: [], visits: 0, new_dealers: 0 }) : http('/reports/digest?day=' + day),
  dashboard: () => USE_MOCK ? mock.empty({ date: '', today: { sales: { amount: 0, units: 0, margin: 0, margin_pct: 0 }, collections: 0 }, mtd: { sales: { amount: 0, units: 0, margin: 0, margin_pct: 0 }, collections: 0, top_dealers: [] }, outstanding: 0, over90: 0, forecast: { week1: 0, next30: 0, at_risk: 0 }, slowing: [], slowing_count: 0, inactive: { count: 0, regular_lost: 0, lost_revenue: 0, rows: [] }, schemes: { earned: 0, potential: 0, progress: 0, rows: [], alerts: [] }, low_stock: [], stock: { value: 0, units: 0 }, pending_approvals: 0, cheques: { due: 0, future: 0, rows: [] }, cheque_alerts: { due_today: [], overdue: [], due_today_total: 0, overdue_total: 0 }, top_overdue: [] }) : http('/reports/dashboard'),
  reportBeat: (from, to) => USE_MOCK ? mock.reportBeat(from, to) : http('/reports/beat?from=' + from + '&to=' + to),
  reportFollowup: (f = {}) => USE_MOCK ? mock.reportFollowup() : http('/reports/followup?' + new URLSearchParams(Object.entries(f).filter(([, v]) => v !== '' && v != null)).toString()),
  agingStock: (days = 60) => USE_MOCK ? mock.agingStock(days) : http('/catalog/aging-stock?days=' + days),
  backup: () => USE_MOCK ? mock.backup() : http('/backup'),
  addBill: (id, bill) => USE_MOCK ? mock.addBill(id, bill) : http('/dealers/' + id + '/bills', { method: 'POST', body: bill }),
  billDetail: (bid) => USE_MOCK ? mock.billDetail(bid) : http('/bills/' + bid),
  deleteBill: (bid) => USE_MOCK ? mock.deleteBill(bid) : http('/bills/' + bid, { method: 'DELETE' }),
  importBatches: () => USE_MOCK ? mock.importBatches() : http('/import/batches'),
  duplicateSales: () => USE_MOCK ? mock.empty({ lines: 0, amount: 0, by_batch: [] }) : http('/import/duplicates'),
  removeDuplicateSales: () => USE_MOCK ? mock.empty({ removed: 0, amount: 0 }) : http('/import/duplicates/remove', { method: 'POST' }),
  undoImport: (id) => USE_MOCK ? mock.undoImport(id) : http('/import/batches/' + id + '/undo', { method: 'POST' }),
  dealerDuplicates: () => USE_MOCK ? mock.dealerDuplicates() : http('/dealers/duplicates'),
  mergeDealers: (id, source_ids) => USE_MOCK ? mock.mergeDealers(id, source_ids) : http('/dealers/' + id + '/merge', { method: 'POST', body: { source_ids } }),
  seedDealer: (id, payload) => USE_MOCK ? mock.seedDealer(id, payload) : http('/dealers/' + id + '/seed', { method: 'POST', body: payload }),
  bulkBills: (bills) => USE_MOCK ? mock.bulkBills(bills) : http('/bills/bulk', { method: 'POST', body: { bills } }),
  pendingPayments: () => USE_MOCK ? mock.pendingPayments() : http('/payments/pending'),
  approvePayment: (id, approved) => USE_MOCK ? mock.approvePayment(id, approved) : http('/payments/' + id + '/approve', { method: 'PATCH', body: { approved } }),
  deletePayment: (id) => USE_MOCK ? mock.deletePayment(id) : http('/payments/' + id, { method: 'DELETE' }),
  collections: (reconciled) => USE_MOCK ? mock.collections(reconciled) : http('/payments/collections' + (reconciled === undefined ? '' : '?reconciled=' + reconciled)),
  reconcilePayment: (id, reconciled) => USE_MOCK ? mock.reconcilePayment(id, reconciled) : http('/payments/' + id + '/reconcile', { method: 'PATCH', body: { reconciled } }),
  parseInvoice: (file) => { if (USE_MOCK) return mock.parseInvoice(file); const fd = new FormData(); fd.append('file', file); return httpForm('/invoices/parse', fd) },
  delDealer: (id) => USE_MOCK ? mock.del('dealers', id) : http('/dealers/' + id, { method: 'DELETE' }),

  stock: () => USE_MOCK ? mock.list('stock') : http('/stock'),
  saveStock: (s) => USE_MOCK ? mock.save('stock', s)
    : http(s.id ? '/stock/' + s.id : '/stock', { method: s.id ? 'PATCH' : 'POST', body: s }),
  delStock: (id) => USE_MOCK ? mock.del('stock', id) : http('/stock/' + id, { method: 'DELETE' }),
  importSalePreview: (file) => { if (USE_MOCK) return mock.importSalePreview(file); const fd = new FormData(); fd.append('file', file); return httpForm('/import/sale/preview', fd) },
  importSaleCommit: (file, fmt = 'dmy') => { if (USE_MOCK) return mock.importSaleCommit(file); const fd = new FormData(); fd.append('file', file); return httpForm('/import/sale/commit?date_format=' + fmt, fd) },
  importPurchasePreview: (file) => { if (USE_MOCK) return mock.importPurchasePreview(file); const fd = new FormData(); fd.append('file', file); return httpForm('/import/purchase/preview', fd) },
  importPurchaseCommit: (file, fmt = 'dmy') => { if (USE_MOCK) return mock.importPurchaseCommit(file); const fd = new FormData(); fd.append('file', file); return httpForm('/import/purchase/commit?date_format=' + fmt, fd) },
  catalogUnits: (params = '') => USE_MOCK ? mock.catalogUnits(params) : http('/catalog/units' + params),
  imeiLookup: (imei) => USE_MOCK ? mock.imeiLookup(imei) : http('/catalog/imei/' + encodeURIComponent(imei)),
  modelHistory: (model) => USE_MOCK ? mock.empty({ model, brand: '', available: 0, total: 0, purchased: { units: 0, value: 0 }, sold: { units: 0, value: 0 }, purchases: [], sales: [] }) : http('/catalog/model-history?model=' + encodeURIComponent(model)),
  stockSummary: () => USE_MOCK ? mock.stockSummary() : http('/catalog/stock-summary'),
  payables: (status) => USE_MOCK ? mock.empty({ rows: [], summary: [], totals: { outstanding: 0, overdue: 0, due_7: 0, bills: 0 } }) : http('/payables?status=' + (status || 'outstanding')),
  payableBrandTerms: () => USE_MOCK ? mock.empty({ brands: [] }) : http('/payables/brand-terms'),
  savePayableBrandTerm: (body) => USE_MOCK ? mock.empty({ ok: true }) : http('/payables/brand-terms', { method: 'PUT', body }),
  savePayableBill: (body) => USE_MOCK ? mock.empty({ ok: true }) : http('/payables/bill', { method: 'POST', body }),

  users: () => USE_MOCK ? mock.list('users') : http('/users'),
  saveUser: (u) => USE_MOCK ? mock.save('users', u)
    : http(u.id ? '/users/' + u.id : '/users', { method: u.id ? 'PATCH' : 'POST', body: u }),
  delUser: (id) => USE_MOCK ? mock.del('users', id) : http('/users/' + id, { method: 'DELETE' }),

  payments: (query = '') => USE_MOCK ? mock.payments(query) : http('/payments' + query),
  collect: (b) => USE_MOCK ? mock.collect(b) : http('/payments', { method: 'POST', body: b }),
  deposit: (cid) => USE_MOCK ? mock.deposit(cid) : http('/payments/deposit', { method: 'POST', body: { collector_id: cid } }),
  cheque: (id, cleared) => USE_MOCK ? mock.cheque(id, cleared) : http('/payments/' + id + '/cheque', { method: 'PATCH', body: { cleared } }),

  pricelists: () => USE_MOCK ? mock.pricelists() : http('/pricelists'),
  createPricelist: (body) => USE_MOCK ? mock.createPricelist(body) : http('/pricelists', { method: 'POST', body }),
  updatePricelist: (id, body) => USE_MOCK ? mock.updatePricelist(id, body) : http('/pricelists/' + id, { method: 'PATCH', body }),
  deletePricelist: (id) => USE_MOCK ? mock.deletePricelist(id) : http('/pricelists/' + id, { method: 'DELETE' }),
  pricelistProducts: (id) => USE_MOCK ? mock.pricelistProducts(id) : http('/pricelists/' + id + '/products'),
  importPricelist: (id, products) => USE_MOCK ? mock.importPricelist(id, products) : http('/pricelists/' + id + '/products/bulk', { method: 'POST', body: { products } }),
  importFlexible: (plid, payload) => USE_MOCK ? mock.importFlexible(plid, payload) : http('/pricelists/' + plid + '/import', { method: 'POST', body: payload }),
  addProduct: (plid, cells) => USE_MOCK ? mock.addProduct(plid, cells) : http('/pricelists/' + plid + '/products/one', { method: 'POST', body: { cells } }),
  updateProduct: (plid, pid, cells) => USE_MOCK ? mock.updateProduct(plid, pid, cells) : http('/pricelists/' + plid + '/products/' + pid, { method: 'PATCH', body: { cells } }),
  deleteProduct: (plid, pid) => USE_MOCK ? mock.deleteProduct(plid, pid) : http('/pricelists/' + plid + '/products/' + pid, { method: 'DELETE' }),
  deleteColumn: (plid, col) => USE_MOCK ? mock.deleteColumn(plid, col) : http('/pricelists/' + plid + '/columns/' + encodeURIComponent(col), { method: 'DELETE' }),
  selectableUsers: () => USE_MOCK ? mock.selectableUsers() : http('/users/selectable'),
}
